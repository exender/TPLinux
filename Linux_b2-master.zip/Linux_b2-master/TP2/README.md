# README

## I. Déploiement simple

Voir dossier Partie1 du git dans lequel vous trouverez le Vagrantfile ainsi que le script bash

## III. Multi-node deployment

Voir dossier Partie3 du git dans lequel vous trouverez le Vagrantfile.

## IV. Automation here we (slowly) come

Voir dossier Partie4 du git dans lequel vous trouverez le Vagrantfile ainsi que les script bash